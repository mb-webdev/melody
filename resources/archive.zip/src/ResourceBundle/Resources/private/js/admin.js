$(document).ready(function(){
    if ($("div.alert").length > 0) {
        setTimeout(function(){
            $("div.alert").fadeOut();
        },
        5000);
    }
});