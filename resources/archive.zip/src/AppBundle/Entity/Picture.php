<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Picture
 *
 * @ORM\Table(name="picture")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\PictureRepository")
 * @ORM\HasLifecycleCallbacks
 */
class Picture
{
    /*************************
     * Constants
     *************************/
    const SIZE_THUMB = 1110;
    const SIZE_THUMB_LIST = 350;
    const SIZE_THUMB_PREVIEW = 200;

    /*************************
     * Properties
     *************************/

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="path", type="string", length=255, nullable=true)
     */
    private $path;

    /**
     * @Assert\File(maxSize="6000000")
     */
    private $file;

    /**
     * @var post
     *
     * @ORM\OneToOne(targetEntity="AppBundle\Entity\Post", mappedBy="thumb")
     */
    private $post;

    private $temp;

    /*************************
     * Getter / Setter
     *************************/

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return Picture
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * Sets file.
     *
     * @param UploadedFile $file
     */
    public function setFile(UploadedFile $file = null)
    {
        $this->file = $file;
        // check if we have an old image path
        if (isset($this->path)) {
            // store the old name to delete after the update
            $this->temp = $this->path;
            $this->path = null;
        } else {
            $this->path = 'initial';
        }
    }

    /**
     * Get file.
     *
     * @return UploadedFile
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * Set post
     *
     * @param Post $post
     *
     * @return Picture
     */
    public function setPost($post)
    {
        $this->post = $post;

        return $this;
    }

    /**
     * Get post
     *
     * @return Post
     */
    public function getPost()
    {
        return $this->post;
    }

    /*************************
     * Custom methods
     *************************/

    /**
     *
     * @return string | null
     */
    public function getAbsolutePath()
    {
        return null === $this->path
        ? null
        : $this->getUploadRootDir().'/'.$this->path;
    }

    /**
     *
     * @return string | null
     */
    public function getWebPath($size = null)
    {
        if (!$this->path) {
            return null;
        }

        if (!$size) {
            return $this->getUploadDir() . DIRECTORY_SEPARATOR . $this->path;
        }

        $name = substr($this->path, 0, strrpos($this->path, '.'));
        $ext = substr($this->path, strrpos($this->path, '.') + 1);

        return $this->getUploadDir() . DIRECTORY_SEPARATOR . $name . '_' . $size . '.' . $ext;
    }

    /**
     *
     * @return string
     */
    protected function getUploadRootDir()
    {
        // the absolute directory path where uploaded
        // documents should be saved
        return __DIR__.'/../../../web/'.$this->getUploadDir();
    }

    /**
     *
     * @return string
     */
    protected function getUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return 'medias/thumb';
    }

    /*************************
     * Doctrine LifeCycle
     *************************/

    /**
     * @ORM\PrePersist()
     * @ORM\PreUpdate()
     */
    public function preUpload()
    {
        if (null !== $this->getFile()) {
            // do whatever you want to generate a unique name
            $filename = sha1(uniqid(mt_rand(), true));
            $this->path = $filename.'.'.$this->getFile()->guessExtension();
        }
    }

    /**
     * @ORM\PostPersist()
     * @ORM\PostUpdate()
     */
    public function upload()
    {
        if (null === $this->getFile()) {
            return;
        }

        // check extension
        if (!in_array($this->getFile()->guessExtension(), array('jpg', 'jpeg', 'png', 'gif'))) {
            unlink($this->getFile()->getRealPath());
            return;
        }

        // if there is an error when moving the file, an exception will
        // be automatically thrown by move(). This will properly prevent
        // the entity from being persisted to the database on error
        $this->getFile()->move($this->getUploadRootDir(), $this->path);

        $this->resize_image($this->getUploadRootDir(), $this->path, static::SIZE_THUMB);
        $this->resize_image($this->getUploadRootDir(), $this->path, static::SIZE_THUMB_LIST);
        $this->resize_image($this->getUploadRootDir(), $this->path, static::SIZE_THUMB_PREVIEW);

        // check if we have an old image
        if (isset($this->temp)) {
            // delete the old image
            $this->removeFile($this->getUploadRootDir() . DIRECTORY_SEPARATOR . $this->temp);
            // clear the temp image path
            $this->temp = null;
        }
        $this->file = null;
    }

    /**
     * @ORM\PostRemove()
     */
    public function removeUpload()
    {
        $file = $this->getAbsolutePath();
        if ($file) {
            $this->removeFile($file);
        }
    }

    private function removeFile($fullPath)
    {
        $name = substr($fullPath, 0, strrpos($fullPath, '.'));
        $ext = substr($fullPath, strrpos($fullPath, '.') + 1);

        if (file_exists($name . '.' . $ext)) {
            unlink($name . '.' . $ext);
        }

        if (file_exists($name . '_' . static::SIZE_THUMB . '.' . $ext)) {
            unlink($name . '_' . static::SIZE_THUMB . '.' . $ext);
        }

        if (file_exists($name . '_' . static::SIZE_THUMB_LIST . '.' . $ext)) {
            unlink($name . '_' . static::SIZE_THUMB_LIST . '.' . $ext);
        }

        if (file_exists($name . '_' . static::SIZE_THUMB_PREVIEW . '.' . $ext)) {
            unlink($name . '_' . static::SIZE_THUMB_PREVIEW . '.' . $ext);
        }
    }

    private function resize_image($folder, $filename, $w) {
        $name = substr($filename, 0, strrpos($filename, '.'));
        $ext = substr($filename, strrpos($filename, '.') + 1);

        $src = null;

        switch ($ext) {
            case "jpg":
            case "jpeg":
                $src = imagecreatefromjpeg($folder . DIRECTORY_SEPARATOR . $name . '.' . $ext);
                break;
            case "png":
                $src = imagecreatefrompng($folder . DIRECTORY_SEPARATOR . $name . '.' . $ext);
                break;
            case "gif":
                $src = imagecreatefromgif($folder . DIRECTORY_SEPARATOR . $name . '.' . $ext);
                break;
            default:
                dump("ext nok : " . $ext);
                return false;
        }

        list($width, $height) = getimagesize($folder . DIRECTORY_SEPARATOR . $name . '.' . $ext);
        $r = $width / $height;
        $newheight = $w/$r;
        $newwidth = $w;

        $dst = imagecreatetruecolor($newwidth, $newheight);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

        $name = $folder . DIRECTORY_SEPARATOR . $name . '_' . $w . '.' . $ext;

        switch ($ext) {
            case "jpg":
            case "jpeg":
                imagejpeg($dst, $name);
                break;
            case "png":
                imagepng($dst, $name);
                break;
            case "gif":
                imagegif($dst, $name);
                break;
            default:
                return null;
        }


        return true;
    }
}

