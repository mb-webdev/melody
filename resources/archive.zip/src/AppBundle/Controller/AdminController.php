<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Post;
use AppBundle\Form\Type\PostType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;

class AdminController extends Controller
{
    public function redirectAction(Request $request)
    {
        return $this->redirectToRoute('app_admin_homepage');
    }

    public function indexAction(Request $request)
    {
        $posts = $this->getDoctrine()->getRepository('AppBundle:Post')->getCount();

        return $this->render('AppBundle:admin:index.html.twig', array(
            'count' => array('posts' => $posts)
        ));
    }

    public function twoFactorAction(Request $request)
    {
        $url = null;

        if(!is_null($this->getUser()->getGoogleAuthenticatorCode())) {
            /* $helper \AppBundle\Security\Helper */
            $helper = $this->get('google_helper');

            $url = $helper->getUrl($this->getUser());
        }

        return $this->render('AppBundle:admin:two-factor.html.twig', array(
            'url' => $url
        ));
    }

    public function twoFactorCreateAction(Request $request)
    {
        /* $helper \AppBundle\Security\Helper */
        $helper = $this->get('google_helper');

        if(is_null($this->getUser()->getGoogleAuthenticatorCode())) {
            $code = $helper->generateSecret();
            $this->getUser()->setGoogleAuthenticatorCode($code);
            $em = $this->getDoctrine()->getManager();
            $em->persist($this->getUser());
            $em->flush();
        }

        return $this->redirectToRoute('app_admin_two_factor');
    }

    public function twoFactorRemoveAction(Request $request)
    {
        $this->getUser()->setGoogleAuthenticatorCode(null);
        $em = $this->getDoctrine()->getManager();
        $em->persist($this->getUser());
        $em->flush();

        return $this->redirectToRoute('app_admin_two_factor');
    }

    public function postsAction(Request $request)
    {
        $posts = $this->getDoctrine()->getRepository('AppBundle:Post')->getPosts();

        return $this->render('AppBundle:admin:posts/index.html.twig', array(
            'posts' => $posts
        ));
    }

    public function addPostAction(Request $request)
    {
        $post = new Post();

        $form = $this->createForm(PostType::class, $post);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $post->setCreationDate(new \DateTime());
            $post->setLastEditDate(new \DateTime());
            $em = $this->getDoctrine()->getManager();
            $em->persist($post);
            $em->flush();

            $this->addFlash('success', 'flash.saved');

            return $this->redirectToRoute('app_admin_posts_edit', array('post' => $post->getId()));
        }

        return $this->render('AppBundle:admin:posts/edit.html.twig', array(
            'post' => null,
            'form' => $form->createView(),
        ));
    }

    /**
     * @ParamConverter("post", class="AppBundle:Post")
     *
     * @param Post $post
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function editPostAction(Post $post, Request $request)
    {
        $form = $this->createForm(PostType::class, $post);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $post->setLastEditDate(new \DateTime());
            $em = $this->getDoctrine()->getManager();
            $em->persist($post);
            $em->flush();

            $this->addFlash('success', 'flash.saved');
        }

        return $this->render('AppBundle:admin:posts/edit.html.twig', array(
                'post' => $post,
                'form' => $form->createView(),
        ));
    }
}
