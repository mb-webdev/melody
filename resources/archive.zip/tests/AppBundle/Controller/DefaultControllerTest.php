<?php

namespace Tests\AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DefaultControllerTest extends WebTestCase
{
    public function testRedirect()
    {
        $client = static::createClient();
        $client->followRedirects();

        $crawler = $client->request('GET', '/');

        $this->assertEquals(1, $crawler->filter("html[lang='fr']")->count());
    }

    public function testFR()
    {
        $client = static::createClient();
        $client->followRedirects();

        $crawler = $client->request('GET', '/fr');

        $this->assertEquals(1, $crawler->filter("html[lang='fr']")->count());
    }

    public function testIEN()
    {
        $client = static::createClient();
        $client->followRedirects();

        $crawler = $client->request('GET', '/en');

        $this->assertEquals(1, $crawler->filter("html[lang='en']")->count());
    }
}
