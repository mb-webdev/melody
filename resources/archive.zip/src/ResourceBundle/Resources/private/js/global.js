$(document).ready(function(){
    respondMobile();

    $( window ).resize(function() {
        respondMobile();
    });
});

function respondMobile() {
    if($(document).width() < 752){
        $("#nav ul.lang a").on("click", respondMobileLangMenu);
    } else {
        $("#nav ul.lang").removeClass("active");
        $("#nav ul.lang a").off("click", respondMobileLangMenu);
    }
}

function respondMobileLangMenu(e) {
    if(!$(this).closest("ul.lang").hasClass("active")) {
        e.preventDefault();
        $(this).closest("ul.lang").addClass("active");
    } else if ($(this).data("lang") == $("html").attr("lang")) {
        e.preventDefault();
        $(this).closest("ul.lang").removeClass("active");
    }
}