<?php

namespace ResourceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ResourceBundle extends Bundle
{
}
