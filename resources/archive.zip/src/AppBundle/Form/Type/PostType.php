<?php

namespace AppBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use AppBundle\Entity\Post;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;

class PostType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('title', TextType::class, array(
            'label' => 'post.key.title',
            'attr' => array(
                'placeholder' => 'post.placeholder.title',
            ),
            'required' => true
        ))
        ->add('slug', TextType::class, array(
            'label' => 'post.key.slug',
            'attr' => array(
                'placeholder' => 'post.placeholder.slug',
            ),
            'required' => true
        ))
        ->add('status', ChoiceType::class, array(
            'label' => 'post.key.status',
            'choices' => array(
                'post.values.status.draft' => Post::STATUS_DRAFT,
                'post.values.status.published' => Post::STATUS_PUBLISHED,
                'post.values.status.removed' => Post::STATUS_REMOVED
            ),
            'empty_data' => Post::STATUS_DRAFT,
            'required' => true
        ))
        ->add('promoted', CheckboxType::class, array(
                'label' => 'post.key.promoted',
                'required' => false
        ))
        ->add('thumb', PictureType::class, array(
                'label' => false,
                'required' => false
        ))
        ->add('intro', TextareaType::class, array(
            'label' => 'post.key.intro',
            'required' => false
        ))
        ->add('content', TextareaType::class, array(
            'label' => 'post.key.content',
            'attr' => array(
                'class' => 'tinymce',
            ),
            'required' => true
        ))
        ->add('author', EntityType::class, array(
            'label' => 'post.key.author',
            'class' => 'AppBundle:User',
            'choice_label' => 'username',
            'required' => true
        ))
        ->add('publicationDate', DateTimeType::class, array(
            'label' => 'post.key.publication',
            'date_widget' => 'single_text',
            'time_widget' => 'single_text',
            'required' => false
        ));
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\Post',
            'translation_domain' => 'admin'
        ));
    }

    public function getName()
    {
        return 'post';
    }
}