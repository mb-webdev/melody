<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Post;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;

class DefaultController extends Controller
{
    public function redirectAction()
    {
        return $this->redirect($this->generateUrl('app_homepage', array('_locale' => $this->getParameter('locale'))));
    }

    public function indexAction(Request $request)
    {
        $promoted = $this->getDoctrine()->getRepository('AppBundle:Post')->getPromoted();
        $posts = $this->getPosts('app_homepage', 1, 3, array('status' => Post::STATUS_PUBLISHED));

        return $this->render('AppBundle:site:index.html.twig', array(
            'promoted' => $promoted,
            'posts' => $posts
        ));
    }

    public function ieAction(Request $request)
    {
        return $this->render('AppBundle:site:ie.html.twig');
    }

    public function postsAction($page = 1, Request $request)
    {
        $posts = $this->getPosts('app_posts', $page, 3, array('status' => Post::STATUS_PUBLISHED), true, 4);

        return $this->render('AppBundle:site:posts.html.twig', array(
            'posts' => $posts
        ));
    }

    /**
     * @ParamConverter("post", class="AppBundle:Post", options={"mapping": {"post": "slug"}})
     *
     * @param Post $post
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function postAction(Post $post, Request $request)
    {

        return $this->render('AppBundle:site:post.html.twig', array(
            'post' => $post,
        ));
    }

    private function getPosts($route, $page = 1, $size = 20, $filters = array(), $pagination = false, $maxDisplay = 0)
    {
        $results = array(
            'route' => $route,
            'results' => $this->getDoctrine()->getRepository('AppBundle:Post')->getPosts($page, $size, array('status' => Post::STATUS_PUBLISHED)),
            'page' => $page,
            'size' => $size,
            'total' => $this->getDoctrine()->getRepository('AppBundle:Post')->getCount(array('status' => Post::STATUS_PUBLISHED)),
            'pagination' => $pagination,
            'max_display' => $maxDisplay
        );
        $results['max_page'] = ceil($results['total'] / $size);

        return $results;
    }
}
